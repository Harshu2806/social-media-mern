
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import InputField from '../DumbComponents/InputFiled';

const Login = () => {
    const navigate = useNavigate();
    const [showPassword, setShowPassword] = useState(false);
    const formik = useFormik({
        initialValues: {
            email: '',
            password: '',
        },
        validationSchema: Yup.object({
            email: Yup.string().email('Invalid email address').required('Email is required'),
            password: Yup.string().required('Password is required'),
        }),
        onSubmit: async (values, { setSubmitting }) => {
            try {
                // Send login request to the server
                const response = await axios.post('http://localhost:5000/api/login', {
                    email: values.email,
                    password: values.password,
                });

                // Handle successful login
                console.log('Login successful:', response.data.message);


                localStorage.setItem('token', response.data.token);

                navigate('/posts');
                toast.success('Login successful!');
            } catch (error) {

                console.error('Error logging in:', error.response.data.message);
                if (error.response && error.response.data.message) {
                    toast.error(error.response.data.message);
                } else {
                    toast.error('An error occurred. Please try again later.');
                }
            } finally {

                setSubmitting(false);
            }
        },
    });
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
    const comingSoonResetPassword = () => toast.warn('Feature Coming Soon')
    return (
        <div class="container flex justify-center items-center flex-col min-w-[1500px] px-4 py-8">
            <form onSubmit={formik.handleSubmit} class="max-w-md mx-auto p-8 bg-white shadow-md rounded-md">
                <h1 class="text-2xl font-semibold mb-6 text-center">Login</h1>


                <ToastContainer />

                <div class="mb-6">
                    <InputField
                        label="Email"
                        id="email"
                        name="email"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.email}
                    />
                    {formik.touched.email && formik.errors.email && (
                        <div class="text-red-500 text-xs mt-1">{formik.errors.email}</div>
                    )}
                </div>

                <div class="mb-6">

                    <div className='relative'>
                        <InputField
                            label="Password"
                            id="password"
                            name="password"
                            type={showPassword ? 'text' : 'password'}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.password}
                        />

                        <span
                            onClick={togglePasswordVisibility}
                            className="absolute top-[65%] right-0 transform translate-y-[-50%] flex items-center pr-2 cursor-pointer"
                        >
                            {showPassword ? '🙈' : '👁️'}
                        </span>
                    </div>

                    {formik.touched.password && formik.errors.password && (
                        <div class="text-red-500 text-xs mt-1">{formik.errors.password}</div>
                    )}
                </div>


                <button
                    type="submit"
                    disabled={formik.isSubmitting || !formik.isValid}
                    class="bg-blue-500 text-white p-3 mr-10 rounded-md hover:bg-blue-600 focus:outline-none"
                >
                    Log In
                </button>
                <button type='button' onClick={comingSoonResetPassword} class="text-blue-600 hover:underline" >
                    Reset Password
                </button>

                <div class="mt-4 text-center text-gray-600">
                    Don't have an account?{' '}
                    <Link to="/signup" class="text-blue-600 hover:underline">
                        Sign Up
                    </Link>
                </div>
            </form>
        </div>

    );
};

export default Login;
