// SignUp.js

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import InputField from '../DumbComponents/InputFiled';

const SignUp = () => {
    const navigate = useNavigate();
    const [showPassword, setShowPassword] = useState(false);

    const formik = useFormik({
        initialValues: {
            username: '',
            email: '',
            password: '',
            confirmPassword: '',
            name: '',
            profilePicture: '',
            termsAndConditions: false,
        },
        validationSchema: Yup.object({
            username: Yup.string().required('Username is required'),
            email: Yup.string().email('Invalid email address').required('Email is required'),
            password: Yup.string().required('Password is required'),
            confirmPassword: Yup.string()
                .oneOf([Yup.ref('password'), null], 'Passwords must match')
                .required('Confirm Password is required'),
            name: Yup.string(),
            profilePicture: Yup.string(),
            termsAndConditions: Yup.boolean().oneOf([true], 'Accept terms and conditions is required'),
        }),
        onSubmit: async (values, { setSubmitting }) => {
            try {
                // Send registration request to the server
                const response = await axios.post('http://localhost:5000/api/register', {
                    name: values.name,
                    email: values.email,
                    password: values.password,
                });


                console.log('Registration successful:', response.data.message);

                // Store the token in localStorage
                localStorage.setItem('token', response.data.token);


                console.log('Sending welcome email to:', values.email);


                navigate('/posts');
                toast.success('Registration successful!');
            } catch (error) {
                // Handle registration error
                if (error.response && error.response.data.message) {
                    toast.error(error.response.data.message);
                } else {
                    toast.error('An error occurred. Please try again later.');
                }

            } finally {
                // Reset form after submission
                setSubmitting(false);
            }
        },
        validate: values => {
            if (showPassword && !values.password) {
                return { password: 'Password is required' };
            }
            return {};
        },
    });
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div className="flex items-center justify-center h-screen flex-col min-w-[1500px]">
            <form onSubmit={formik.handleSubmit} className="max-w-md block  bg-white p-8 rounded-lg shadow-md">
                <ToastContainer />
                {/* Username */}

                <div className="mb-4">

                    <InputField
                        label="Username"
                        id="username"
                        name="username"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.username}
                        error={formik.touched.username && formik.errors.username}
                    />

                </div>

                {/* Email */}
                <div className="mb-4">

                    <InputField
                        label="Email"
                        id="email"
                        name="email"
                        type="email"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.email}
                        error={formik.touched.email && formik.errors.email}
                    />

                </div>

                {/* Password */}
                <div className="mb-4">

                    <div className="relative">
                        <InputField
                            label="Password"
                            id="password"
                            name="password"
                            type={showPassword ? 'text' : 'password'}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.password}
                            error={formik.touched.password && formik.errors.password}
                        />

                        <span
                            onClick={togglePasswordVisibility}
                            className="absolute top-[65%] right-0 transform translate-y-[-50%] flex items-center pr-2 cursor-pointer"
                        >
                            {showPassword ? '🙈' : '👁️'}
                        </span>
                    </div>

                </div>

                {/* Confirm Password */}
                <div className="mb-4">

                    <InputField
                        label="Confirm Password"
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.confirmPassword}
                        error={formik.touched.confirmPassword && formik.errors.confirmPassword}
                    />

                </div>

                {/* Name */}
                <div className="mb-4">

                    <InputField
                        label="Name"
                        id="name"
                        name="name"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.name}
                        error={formik.touched.name && formik.errors.name}
                    />

                </div>

                {/* Terms and Conditions */}
                <div className="mb-4">
                    <label className="flex items-center">
                        <input
                            type="checkbox"
                            id="termsAndConditions"
                            name="termsAndConditions"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            checked={formik.values.termsAndConditions}
                            className="mr-2"
                        />
                        <span className="text-blue-500">
                            I accept the{' '}
                            <Link to="/terms" className="text-blue-500 underline">
                                Terms and Conditions
                            </Link>
                        </span>
                    </label>
                    {formik.touched.termsAndConditions && formik.errors.termsAndConditions && (
                        <div className="text-red-500 text-sm mt-1">{formik.errors.termsAndConditions}</div>
                    )}
                </div>

                {/* Submit Button */}
                <button
                    type="submit"
                    disabled={formik.isSubmitting || !formik.isValid}
                    className="bg-blue-500 text-white p-3 rounded-md hover:bg-blue-600 focus:outline-none"
                >
                    Sign Up
                </button>
            </form>

            {/* Login Link */}
            <div className="mt-4 text-center">
                Already have an account?{' '}
                <Link to="/login" className="text-blue-500 underline">
                    Log In
                </Link>
            </div>
        </div>

    );
};

export default SignUp;
