import React, { useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const PasswordReset = () => {
    const navigate = useNavigate();
    const { resetToken } = useParams();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const handleResetPassword = async (e) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            toast.error('Passwords do not match');
            return;
        }

        try {

            const response = await axios.post('http://localhost:5000/api/reset-password', {
                token: resetToken,
                password,
            });

            toast.success(response.data.message);
            // Redirect to the login page after successful password reset
            navigate('/login');
        } catch (err) {
            toast.error(err.response.data.message || 'An error occurred. Please try again.');
        }
    };
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
    return (
        <div className="container mx-auto px-4 py-8">
            <form onSubmit={handleResetPassword} className="max-w-md mx-auto p-8 bg-white shadow-md rounded-md">
                <h1 className="text-2xl font-semibold mb-6 text-center">Password Reset</h1>

                <ToastContainer />

                <label className="block text-sm font-medium text-gray-700 mb-2">
                    New Password:
                </label>
                <div className='relative'>
                    <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"
                        required
                    />
                    <span
                        onClick={togglePasswordVisibility}
                        className="absolute inset-y-0 right-0 flex items-center pr-2 cursor-pointer"
                    >
                        {showPassword ? '🙈' : '👁️'}
                    </span>
                </div>
                <label className="block text-sm font-medium text-gray-700 mb-2 mt-4">
                    Confirm Password:
                </label>

                <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"
                    required
                />

                <button
                    type="submit"
                    className="w-full py-2 text-center text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 mt-6"
                >
                    Reset Password
                </button>
            </form>
        </div>
    );
};

export default PasswordReset;
