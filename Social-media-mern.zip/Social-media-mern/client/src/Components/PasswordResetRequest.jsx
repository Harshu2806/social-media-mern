import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const PasswordResetRequest = () => {
    const [enteredEmail, setEnteredEmail] = useState('');
    const navigate = useNavigate();
    const handlePasswordResetRequest = async () => {
        try {
            const response = await axios.post('http://localhost:5000/api/request-password-reset', {
                email: enteredEmail,
            });
            // Display success message to the user
            console.log(response.data.message);
            navigate('/resetpassword');
        } catch (error) {

            console.error('Error requesting password reset:', error.response.data.message);
        }
    };

    return (
        <div>
            <label>Email:</label>
            <input
                type="email"
                value={enteredEmail}
                onChange={(e) => setEnteredEmail(e.target.value)}
            />
            <button onClick={handlePasswordResetRequest}>Request Password Reset</button>
        </div>
    );
};

export default PasswordResetRequest;
