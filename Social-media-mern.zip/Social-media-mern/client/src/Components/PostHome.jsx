import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Link, Navigate, useNavigate } from 'react-router-dom';
const PostHome = () => {

    const navigate = useNavigate();
    const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));

    const [postForm, setPostForm] = useState({
        title: '',
        imgUrl: '',
        content: '',
    });


    const [posts, setPosts] = useState([]);

    // Fetch all posts on component mount
    useEffect(() => {

        if (isLoggedIn) {
            fetchPosts();
        }
    }, [isLoggedIn]);


    const fetchPosts = async () => {
        try {

            const token = localStorage.getItem('token');
            console.log(token);
            const headers = {
                Authorization: token,
            };


            const response = await axios.get('http://localhost:5000/api/my-posts', { headers });


            setPosts(response.data.posts);
        } catch (error) {
            console.error('Error fetching posts:', error.message);
            if (error.response) {
                console.error('Response status:', error.response.status);
                console.error('Response data:', error.response.data);
            }
        }
    };



    // Function to handle form submission (create new post)
    const handlePostSubmit = async (e) => {
        e.preventDefault();

        try {

            const token = localStorage.getItem('token');

            const headers = {
                Authorization: token,
            };
            console.log(headers);


            await axios.post('http://localhost:5000/api/posts', postForm, { headers });


            fetchPosts();


            setPostForm({ title: '', imgUrl: '', content: '' });
            toast.success('Post created successfully!');

        } catch (error) {
            console.error('Error creating post:', error.message);
            if (error.response) {
                console.error('Response status:', error.response.status);
                console.error('Response data:', error.response.data);
                const errorMessage = error.response.data.error || 'An error occurred.'; // Extract error message from response if available
                toast.error(errorMessage);

            }
        }
    };
    const handleDeletePost = async (postId) => {
        try {

            const token = localStorage.getItem('token');


            const headers = {
                Authorization: token,
            };


            await axios.delete(`http://localhost:5000/api/posts/${postId}`, { headers });

            // Fetch updated posts after deleting a post
            fetchPosts();

            toast.success('Post deleted successfully!');
        } catch (error) {
            console.error('Error deleting post:', error.message);
            if (error.response) {
                console.error('Response status:', error.response.status);
                console.error('Response data:', error.response.data);
                const errorMessage = error.response.data.error || 'An error occurred.';
                toast.error(errorMessage);
            }
        }
    };
    const handleLogout = async () => {
        // Clear the token from local storage
        await localStorage.removeItem('token');

        await navigate('/login');
        setIsLoggedIn(false);
    };



    // Function to handle form input changes
    const handleInputChange = (e) => {
        setPostForm({ ...postForm, [e.target.name]: e.target.value });
    };

    return (
        <div className='md:min-w-[1500px] sm:w-[360px] flex flex-col md:flex-row'>
            {/* Left side - Post Form */}
            <div className='md:w-1/3 mt-8'>
                <ToastContainer />
                {isLoggedIn ? (
                    <div className="text-center p-4 mt-2 bg-gray-800 text-white">
                        <h2 className="text-2xl font-bold mb-4">Create a New Post</h2>

                        <form onSubmit={handlePostSubmit} className="w-full">
                            <div className="mb-4">
                                <label htmlFor="title" className="block text-sm font-bold mb-2">
                                    Title:
                                </label>
                                <input
                                    type="text"
                                    id="title"
                                    name="title"
                                    value={postForm.title}
                                    onChange={handleInputChange}
                                    className="w-full p-2 border rounded-md"
                                />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="imgUrl" className="block text-sm font-bold mb-2">
                                    Image URL:
                                </label>
                                <input
                                    type="text"
                                    id="imgUrl"
                                    name="imgUrl"
                                    value={postForm.imgUrl}
                                    onChange={handleInputChange}
                                    className="w-full p-2 border rounded-md"
                                />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="content" className="block text-sm font-bold mb-2">
                                    Content:
                                </label>
                                <input
                                    type="text"
                                    id="content"
                                    name="content"
                                    value={postForm.content}
                                    onChange={handleInputChange}
                                    className="w-full p-2 border rounded-md"
                                />
                            </div>

                            <button type="submit" className="bg-blue-500 text-white p-2 rounded-md cursor-pointer mb-4">
                                Post
                            </button>
                        </form>

                        <button onClick={handleLogout} className="bg-red-500 text-white p-2 rounded-md cursor-pointer">
                            Logout
                        </button>
                    </div>
                ) : (
                    <div className="md:w-1/3 p-4 fixed top-20 left-0 bg-gray-800 text-white">
                        <div>Please <Link to="/login" className="text-blue-500 underline">
                            Log In
                        </Link> to access this feature.</div>
                    </div>
                )}
            </div>

            {/* Right side or Middle - Display All Posts */}
            {isLoggedIn && (
                <div className='md:w-2/3 p-4'>
                    <h2 className="text-2xl font-bold mb-4">All Posts</h2>
                    <div className="p-4 overflow-y-auto max-h-full">
                        <div className="h-[97vh]">
                            <div>
                                {Array.isArray(posts) && posts.length > 0 ? (
                                    posts.map((post) => (
                                        <div key={post._id} className="mb-4 bg-white p-4 rounded-md shadow-md">
                                            <h3 className="text-xl text-gray-700 font-bold">{post.title}</h3>
                                            <p className="text-gray-700">{post.content}</p>
                                            <p className="text-gray-500">Posted by: {post.username}</p>
                                            {post.imgUrl && (
                                                <img
                                                    src={post.imgUrl}
                                                    alt={`Image for ${post.title}`}
                                                    className="mt-2 rounded-md"
                                                    style={{ maxWidth: '100%' }}
                                                />
                                            )}
                                            <button
                                                onClick={() => handleDeletePost(post._id)}
                                                className="bg-red-500 text-white p-2 rounded-md cursor-pointer mt-2"
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    ))
                                ) : (
                                    <h3>No Posts Are Here!</h3>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>


    );
};

export default PostHome;
