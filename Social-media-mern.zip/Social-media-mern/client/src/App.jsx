import { jwtDecode } from "jwt-decode";
import './App.css';
import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';



const Login = lazy(() => import('./Components/Login'));
const PostHome = lazy(() => import('./Components/PostHome'));
const Signup = lazy(() => import('./Components/Signup'));
const ResetePassword = lazy(() => import('./Components/PasswordReset'));
const PasswordResetRequest = lazy(() => import('./Components/PasswordResetRequest'));

const getTokenFromLocalStorage = () => localStorage.getItem('token');

const checkIfUserIsLoggedIn = () => {
  const token = getTokenFromLocalStorage();
  console.log(token);

  if (token != "") {
    // Decode the token to check if it's valid and not expired
    try {
      const decodedToken = jwtDecode(token, { complete: true });
      console.log(decodedToken.exp);

      const expirationTime = decodedToken.exp * 1000;


      if (Date.now() < expirationTime) {
        return true;
      }
    } catch (error) {

      console.error('Invalid or expired token:', error);
    }
  }

  return false;
};

function App() {
  const isLoggedIn = checkIfUserIsLoggedIn();
  console.log(isLoggedIn);

  return (
    <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={isLoggedIn ? <Navigate to="/posts" /> : <Signup />} />
          <Route path="/posts" element={<PostHome />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/resetpassword" element={<ResetePassword />} />
          <Route path="/passresetrequest" element={<PasswordResetRequest />} />
        </Routes>
      </Suspense>
    </Router>
  )
}

export default App
