import React from 'react';

const InputField = ({ label, id, name, type, onChange, onBlur, value, error }) => {
    return (
        <div className="mb-4">
            <label htmlFor={id} className="block text-gray-700 text-sm font-bold mb-2">
                {label}:
            </label>
            <input
                type={type}
                id={id}
                name={name}
                onChange={onChange}
                onBlur={onBlur}
                value={value}
                className="w-full p-3 border rounded-md focus:outline-none focus:border-blue-500"
            />
            {error && <div className="text-red-500 text-sm mt-1">{error}</div>}
        </div>
    );
};

export default InputField;
