// JWT configuration and secret key
module.exports = {
    secretKey: 'secret-key'
};
