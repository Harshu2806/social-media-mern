
const dotenv = require('dotenv');
dotenv.config();

module.exports = {
    PORT: process.env.PORT || 5000,
    MONGODB_URI: process.env.MONGODB_URI || 'mongodb+srv://patilharshada6251:QlkhjTlhu24l68Wy@cluster0.txkonvq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
};
