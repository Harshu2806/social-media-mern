const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const { PORT, MONGODB_URI } = require('./config/env');
const secureRoutes = require('./routes/api');

// Database connection
mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error(err));

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Attach secure routes
app.use('/api', secureRoutes);

// Catch-all route for non-existent routes
app.get('*', (req, res) => {
    res.status(404).json({ message: 'Route not found' });
});

const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});

module.exports = server;
