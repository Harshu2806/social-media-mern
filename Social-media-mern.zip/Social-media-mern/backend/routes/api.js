const express = require('express');
const { registerUser, loginUser, resetPassword } = require('../controllers/auth');
const { createPost, getUserPosts, deletePost } = require('../controllers/post');
const authenticateUser = require('../middleware/auth');

const router = express.Router();

// Public routes (no authentication required)
router.post('/register', registerUser);
router.post('/login', loginUser);

// Reset password route
router.post('/reset-password', resetPassword);

// Protected routes (authentication required)
router.post('/posts', authenticateUser, createPost);
router.get('/my-posts', authenticateUser, getUserPosts);
router.delete('/posts/:postId', authenticateUser, deletePost);

module.exports = router;
