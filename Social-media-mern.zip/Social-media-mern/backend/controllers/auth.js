const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('../utils/bcrypt');
const { hashPassword, comparePasswords } = require('../utils/bcrypt');
const User = require('../models/User');

const authenticateUser = (req, res, next) => {

    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized - Missing token' });
    }

    try {
        const decoded = jwt.verify(token, 'secret-key');
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Unauthorized - Invalid token' });
    }
};

const registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Hash password before saving
        const hashedPassword = await hashPassword(password);

        const newUser = new User({
            name,
            email,
            password: hashedPassword
        });

        await newUser.save();

        // Generate JWT token
        const token = jwt.sign({ userId: newUser._id }, 'secret-key', { expiresIn: '3h' });

        res.status(201).json({ message: 'User created successfully', token });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating user' });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user by email
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // Compare password (using bcrypt - not included here for brevity)
        const isMatch = await comparePasswords(password, user.password);

        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // Generate JWT token
        const token = jwt.sign({ userId: user._id }, 'secret-key', { expiresIn: '1h' });

        res.json({ message: 'Login successful', token });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error logging in' });
    }
};

//For now, I haven't implemented any email service to send a new email with a new token. That's why I created a simple API to reset the password.

const requestPasswordReset = async (req, res) => {
    try {
        const { email } = req.body;

        // Find user by email
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Generate a unique token for password reset
        const resetToken = jwt.sign({ userId: user._id }, 'reset-secret-key', { expiresIn: '1h' });

        // Send the reset link to the user's email 

        res.json({ message: 'Password reset link sent to your email' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error requesting password reset' });
    }
};

const resetPassword = async (req, res) => {
    try {
        const { token, password } = req.body;

        // Verify the reset token
        const decoded = jwt.verify(token, 'reset-secret-key');

        // Find user by decoded user ID
        const user = await User.findById(decoded.userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Hash the new password
        const hashedPassword = await hashPassword(password);

        // Update user's password in the database
        user.password = hashedPassword;
        await user.save();

        res.json({ message: 'Password reset successful' });
    } catch (err) {
        console.error(err);
        res.status(401).json({ message: 'Invalid or expired reset token' });
    }
};

module.exports = {
    authenticateUser,
    registerUser,
    loginUser,
    requestPasswordReset,
    resetPassword
};
