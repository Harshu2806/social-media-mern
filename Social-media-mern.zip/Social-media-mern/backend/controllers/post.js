
const User = require('../models/User');
const Post = require('../models/Post');

const createPost = async (req, res) => {
    try {
        const { title, imgUrl, content } = req.body;
        const userId = req.user.userId;

        // Fetch the current user to get the username
        const currentUser = await User.findById(userId);

        if (!currentUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Create a new post for the logged-in user
        const newPost = new Post({
            title,
            imgUrl,
            content,
            user: userId,
            username: currentUser.name
        });

        await newPost.save();

        res.status(201).json({ message: 'Post created successfully', post: newPost });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating post' });
    }
};

const getUserPosts = async (req, res) => {
    try {
        const userId = req.user.userId;

        // Fetch posts for the logged-in user
        const userPosts = await Post.find({ user: userId });

        res.json({ posts: userPosts });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching user posts' });
    }
};

const deletePost = async (req, res) => {
    try {
        const postId = req.params.postId;

        // Check if the post exists
        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        // Check if the logged-in user is the owner of the post
        if (post.user.toString() !== req.user.userId) {
            return res.status(403).json({ message: 'Unauthorized. You can only delete your own posts' });
        }

        // Delete the post
        await Post.deleteOne({ _id: postId }); // Delete by ID

        res.json({ message: 'Post deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting post' });
    }
};


module.exports = {
    createPost,
    getUserPosts,
    deletePost
};
