# Social Media MERN

## Project Overview

This is a Social Media MERN (MongoDB, Express.js, React, Node.js) project that includes both backend and frontend components. Follow the instructions below to set up and run the project.

## Backend Setup

1. Navigate to the `backend` directory using the following command:

   ```bash
   cd backend
   ```

2. Install the required npm packages:

   ```bash
   npm install
   ```

3. Start the Node.js server:

   ```bash
   node server.js
   ```

The backend server should now be running at `http://localhost:5000`.

## Frontend Setup

1. Navigate to the `client` directory using the following command:

   ```bash
   cd client
   ```

2. Install the required npm packages:

   ```bash
   npm install
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

The frontend development server should now be running at `http://localhost:5173`.

Now you should be able to access the full application by navigating to `http://localhost:5173` in your web browser.

Thank You!
